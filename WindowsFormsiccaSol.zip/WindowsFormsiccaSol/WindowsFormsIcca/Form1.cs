﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsIcca
{
    public partial class Form1 : Form
    {
       // DataTable table = new DataTable("table");
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string NAME = textBox1.Text;
            string PASSWORD = textBox2.Text;
            string connectionString = @"Data Source=DESKTOP-IV25UVN\SQLEXPRESS;Initial Catalog=iccaWindowes;Integrated Security=True";
            SqlConnection connectionObject = new SqlConnection(connectionString);
            connectionObject.Open();

            String queryToExecute = "INSERT INTO Table_1 VALUES('" + textBox1.Text + "','" + textBox2.Text + "')";

            SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
            int result = commandObject.ExecuteNonQuery();
            if (result == 1)
            {
                MessageBox.Show("Login Sucessfull");
            }
            else
            {
                MessageBox.Show("Login faliure");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = String.Empty;
            textBox2.Text = String.Empty;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
